export interface Review {
  _id: string,
  message: string,
  author: string
}
