export interface DeliveryMethod {
  id: number,
  name: string,
  price: number,
  eta: number
}
