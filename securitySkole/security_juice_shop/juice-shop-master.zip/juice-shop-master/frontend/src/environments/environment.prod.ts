export const environment = {
  production: true,
  hostServer: '.'
}
