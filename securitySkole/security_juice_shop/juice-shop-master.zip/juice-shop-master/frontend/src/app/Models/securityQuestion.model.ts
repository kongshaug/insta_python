export interface SecurityQuestion {
  id: number,
  question: string
}
