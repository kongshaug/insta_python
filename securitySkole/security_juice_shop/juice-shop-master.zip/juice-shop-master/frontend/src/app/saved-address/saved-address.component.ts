import { Component } from '@angular/core'

@Component({
  selector: 'app-saved-address',
  templateUrl: './saved-address.component.html',
  styleUrls: ['./saved-address.component.scss']
})

export class SavedAddressComponent {
}
