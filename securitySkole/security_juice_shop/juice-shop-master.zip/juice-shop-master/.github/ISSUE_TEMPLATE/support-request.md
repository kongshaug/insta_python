---
name: "❓Support request"
about: Questions and requests for support
title: '[❓] '
labels: 'support'
assignees: ''

---

:stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign:

Please **do not** file questions or support requests on the GitHub issues tracker.

You can get your questions answered using other communication channels.

1. Please first check our collection of [existing Troubleshooting advice](https://bkimminich.gitbooks.io/pwning-owasp-juice-shop/content/appendix/troubleshooting.html).
2. If that did not solve your issue, please ask for help _either_ on [Gitter](https://gitter.im/bkimminich/juice-shop) _or_ on [Reddit](https://www.reddit.com/r/owasp_juiceshop).

Thank you!

:stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign::stop_sign:
